const MAX_IMAGE_DIMENSION = 1600;
const IMAGE_COMPRESSION_QUALITY = 0.72;

const getImageMimeType = (file, fallback = 'image/jpeg') => {
    const type = file?.type || '';
    if (type.startsWith('image/') && !['image/gif', 'image/svg+xml'].includes(type)) {
        return type === 'image/png' ? 'image/jpeg' : type;
    }
    return fallback;
};

export const compressImageFile = async (file, originalName = 'image.jpg') => {
    const fileType = file?.type || '';
    if (!fileType.startsWith('image/') || ['image/gif', 'image/svg+xml'].includes(fileType)) {
        return file;
    }

    const objectUrl = URL.createObjectURL(file);

    try {
        const image = await new Promise((resolve, reject) => {
            const img = new window.Image();
            img.onload = () => resolve(img);
            img.onerror = reject;
            img.src = objectUrl;
        });

        const scale = Math.min(1, MAX_IMAGE_DIMENSION / Math.max(image.width, image.height));
        const width = Math.max(1, Math.round(image.width * scale));
        const height = Math.max(1, Math.round(image.height * scale));

        const canvas = document.createElement('canvas');
        canvas.width = width;
        canvas.height = height;
        const context = canvas.getContext('2d');
        context.drawImage(image, 0, 0, width, height);

        const mimeType = getImageMimeType(file);
        const compressedBlob = await new Promise((resolve) => {
            canvas.toBlob(resolve, mimeType, IMAGE_COMPRESSION_QUALITY);
        });

        if (!compressedBlob || compressedBlob.size >= file.size) {
            return file;
        }

        const outputName = mimeType === 'image/jpeg' && !/\.jpe?g$/i.test(originalName)
            ? (originalName.includes('.') ? originalName.replace(/\.[^.]+$/, '.jpg') : `${originalName}.jpg`)
            : originalName;

        return new File([compressedBlob], outputName, {
            type: mimeType,
            lastModified: Date.now(),
        });
    } catch (error) {
        console.warn('Image compression skipped:', error);
        return file;
    } finally {
        URL.revokeObjectURL(objectUrl);
    }
};
