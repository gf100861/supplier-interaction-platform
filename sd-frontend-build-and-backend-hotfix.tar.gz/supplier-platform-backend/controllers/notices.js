const { createClient } = require('@supabase/supabase-js');
const cors = require('cors');

const corsMiddleware = cors({
    origin: true,
    methods: ['GET', 'POST', 'PATCH', 'DELETE', 'OPTIONS'],
    credentials: true,
});

function runMiddleware(req, res, fn) {
    return new Promise((resolve, reject) => {
        fn(req, res, (result) => {
            if (result instanceof Error) return reject(result);
            return resolve(result);
        });
    });
}

const FULL_NOTICE_SELECT = `
    *,
    creator:users ( id, username, email, role ),
    supplier:suppliers ( parma_id, short_code )
`;

const LIST_NOTICE_SELECT = `
    id,
    notice_code,
    batch_id,
    category,
    title,
    assigned_supplier_id,
    assigned_supplier_name,
    creator_id,
    status,
    created_at,
    creator:users ( id, username, email, role ),
    supplier:suppliers ( parma_id, short_code )
`;

function withListPreviewFields(row) {
    if (!row) return row;
    return {
        ...row,
        sd_notice: {
            createTime: row.created_at,
            description: row.title || '',
            details: {
                finding: '',
                process: row.title || '',
            },
        },
        history: [],
        is_lightweight: true,
    };
}

module.exports = async (req, res) => {
    // CORS
    const requestOrigin = req.headers.origin || '*';
    res.setHeader('Access-Control-Allow-Origin', requestOrigin);
    res.setHeader('Access-Control-Allow-Methods', 'GET,POST,PATCH,DELETE,OPTIONS');
    res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');
    res.setHeader('Access-Control-Allow-Credentials', 'true');

    if (req.method === 'OPTIONS') return res.status(200).end();

    try {
        await runMiddleware(req, res, corsMiddleware);

        const supabaseAdmin = createClient(
            process.env.SUPABASE_URL,
            process.env.SUPABASE_SERVICE_ROLE_KEY
        );

        // --- GET: 获取所有通知单 (🚀 核心优化：按用户角色过滤) ---
        if (req.method === 'GET') {
            // 解析前端 URL 传来的查询参数 (?userId=xxx&role=xxx)
            const { userId, role, id, detail } = req.query || {};

            if (id && detail === 'true') {
                const { data, error } = await supabaseAdmin
                    .from('notices')
                    .select(FULL_NOTICE_SELECT)
                    .eq('id', id)
                    .single();

                if (error) throw error;
                return res.json(data);
            }

            // 1. 构建基础查询
            let query = supabaseAdmin
                .from('notices')
                .select(LIST_NOTICE_SELECT)
                .order('created_at', { ascending: false });

            const limit = Math.min(parseInt(req.query.limit || '50', 10), 500);
            query = query.limit(limit);

            // 2. 🌟 根据身份在数据库层面过滤数据 (动态拼接 WHERE 条件)
            if (role === 'Supplier' && userId) {
                // 【核心修复】：前端传的 userId 是"人员账号"的 ID，而 notices 表存的是 "供应商公司"的 ID (assigned_supplier_id)
                // 先查询当前人员账号绑定的公司 supplier_id
                const { data: userRecord } = await supabaseAdmin
                    .from('users')
                    .select('supplier_id')
                    .eq('id', userId)
                    .single();

                if (userRecord && userRecord.supplier_id) {
                    // 使用查出来的公司 ID 去精准过滤单据
                    query = query.eq('assigned_supplier_id', userRecord.supplier_id);
                } else {
                    // 如果该账号没有绑定公司，出于安全考虑，返回一个必定不匹配的条件让结果为空
                    query = query.eq('id', '00000000-0000-0000-0000-000000000000');
                }
            } 
            else if (role === 'SD' && userId) {
                // SD 默认可以看全部。
                // 如果您希望 SD 只能看自己创建的，可以取消下面这行的注释：
                // query = query.eq('creator_id', userId);
            }
            // Admin 和 Manager 默认不加限制，查看所有数据

            // 3. 执行最终查询
            let { data, error } = await query;

            if (error) {
                console.warn('[Notices API] Lightweight list query failed, falling back to full query:', error.message);

                query = supabaseAdmin
                    .from('notices')
                    .select(FULL_NOTICE_SELECT)
                    .order('created_at', { ascending: false })
                    .limit(limit);

                if (role === 'Supplier' && userId) {
                    const { data: userRecord } = await supabaseAdmin
                        .from('users')
                        .select('supplier_id')
                        .eq('id', userId)
                        .single();

                    if (userRecord && userRecord.supplier_id) {
                        query = query.eq('assigned_supplier_id', userRecord.supplier_id);
                    } else {
                        query = query.eq('id', '00000000-0000-0000-0000-000000000000');
                    }
                }

                const fallback = await query;
                data = fallback.data;
                error = fallback.error;
            }

            if (error) throw error;
            return res.json((data || []).map(withListPreviewFields));
        }

        // --- POST: 创建通知单 (支持批量) ---
        if (req.method === 'POST') {
            const noticesData = req.body;
            // 确保是数组
            const insertData = Array.isArray(noticesData) ? noticesData : [noticesData];

            const { data, error } = await supabaseAdmin
                .from('notices')
                .insert(insertData)
                // 关键: 同时返回 creator 信息，供前端发邮件用
                .select('*, creator:users(username, email)');

            if (error) throw error;
            return res.status(201).json(data);
        }

        // --- PATCH: 更新通知单 ---
        if (req.method === 'PATCH') {
            const { id, updates } = req.body;
            if (!id || !updates) return res.status(400).json({ error: 'Missing id or updates' });

            // 过滤掉前端可能传来的辅助字段 (如 old_supplier_id)，只保留 DB 字段
            // 这里做一个简单的保护，实际应根据 Schema 过滤
            const { old_supplier_id, creator, supplier, ...dbUpdates } = updates;

            const { data, error } = await supabaseAdmin
                .from('notices')
                .update(dbUpdates)
                .eq('id', id)
                .select(`*, creator:users(id, email, username), supplier:suppliers(id, name,short_code)`)
                .single();

            if (error) throw error;
            return res.json(data);
        }

        // --- DELETE: 删除通知单 ---
        if (req.method === 'DELETE') {
            const { ids } = req.body; // Expecting { ids: [1, 2, 3] }
            
            if (!ids || ids.length === 0) return res.status(400).json({ error: 'Missing ids' });

            const { error } = await supabaseAdmin
                .from('notices')
                .delete()
                .in('id', ids);

            if (error) throw error;
            return res.json({ success: true });
        }

        return res.status(405).json({ error: 'Method not allowed' });

    } catch (error) {
        console.error('[Notices API] Error:', error);
        return res.status(500).json({ error: error.message });
    }
};
