export const toPlainText = (value) => {
    if (value == null) return '';
    if (typeof value === 'object' && Array.isArray(value.richText)) {
        return value.richText.map(part => part?.text || '').join('');
    }
    if (typeof value === 'object' && typeof value.richText === 'string') {
        return value.richText;
    }
    if (typeof value === 'object' && typeof value.text === 'string') {
        return value.text;
    }
    return String(value);
};

const formatFile = (file) => {
    if (!file) return '';
    const name = toPlainText(file.name || file.fileName || '文件');
    const url = toPlainText(file.url || file.thumbUrl || '');
    return url ? `${name}: ${url}` : name;
};

export const getActionPlanLines = (history) => {
    const lines = [];
    (Array.isArray(history) ? history : []).forEach(item => {
        if (item?.type !== 'supplier_plan_submission' || !Array.isArray(item.actionPlans)) return;
        item.actionPlans.forEach(plan => {
            if (!plan) return;
            const parts = [toPlainText(plan.plan).trim() || '未填写计划'];
            const responsible = toPlainText(plan.responsible).trim();
            const deadline = toPlainText(plan.deadline).trim();
            if (responsible) parts.push(`负责人: ${responsible}`);
            if (deadline) parts.push(`截止日期: ${deadline.slice(0, 10)}`);
            lines.push(parts.join(' | '));
        });
    });
    return lines;
};

export const getEvidenceLines = (history) => {
    const lines = [];
    (Array.isArray(history) ? history : []).forEach(item => {
        if (item?.type !== 'supplier_evidence_submission' || !Array.isArray(item.actionPlans)) return;
        item.actionPlans.forEach(plan => {
            if (!plan) return;
            const parts = [];
            const description = toPlainText(plan.evidenceDescription).trim();
            if (description) parts.push(`完成说明: ${description}`);

            const images = (Array.isArray(plan.evidenceImages) ? plan.evidenceImages : [])
                .map(formatFile)
                .filter(Boolean);
            if (images.length) parts.push(`图片: ${images.join('; ')}`);

            const attachments = (Array.isArray(plan.evidenceAttachments) ? plan.evidenceAttachments : [])
                .map(formatFile)
                .filter(Boolean);
            if (attachments.length) parts.push(`附件: ${attachments.join('; ')}`);

            if (parts.length) lines.push(parts.join('\n'));
        });
    });
    return lines;
};

export const getNoticeProduct = (notice) => toPlainText(
    notice?.details?.product ||
    notice?.sdNotice?.details?.product ||
    notice?.sdNotice?.problemSource ||
    notice?.sdNotice?.problem_source ||
    ''
);
